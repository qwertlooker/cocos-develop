/****************************************************************************
 Copyright (c) 2017-2018 Xiamen Yaji Software Co., Ltd.
 
 http://www.cocos2d-x.org
 
 Permission is hereby granted, free of charge, to any person obtaining a copy
 of this software and associated documentation files (the "Software"), to deal
 in the Software without restriction, including without limitation the rights
 to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:
 
 The above copyright notice and this permission notice shall be included in
 all copies or substantial portions of the Software.
 
 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 THE SOFTWARE.
 ****************************************************************************/


var HelloWorldLayer = cc.Layer.extend({
    sprite:null,
    
    startTime:Date.now(),
    time:0.0,
    ctor:function () {
        //////////////////////////////
        // 1. super init first
        this._super();

        /////////////////////////////
        // 2. add a menu item with "X" image, which is clicked to quit the program
        //    you may modify it.
        // ask the window size
        var size = cc.winSize;

        /////////////////////////////
        // 3. add your codes below...
        // add a label shows "Hello World"
        // create and initialize a label
        var helloLabel = new cc.LabelTTF("Hello World", "Arial", 38);
        // position the label on the center of the screen
        helloLabel.x = size.width / 2;
        helloLabel.y = size.height / 2 + 200;
        // add the label as a child to this layer
        this.addChild(helloLabel, 5);

        testWater(this);

        testOutline(this);
        // add "HelloWorld" splash screen"
        this.sprite = new cc.Sprite(res.HelloWorld_png);

        testShader(this.sprite, this); 
        this.sprite.attr({
            x: size.width / 2,
            y: size.height / 2
        });
        this.addChild(this.sprite, 0);

        this.scheduleUpdate();
        
        return true;
    },

    update:function(dt) {
        if( 'opengl' in cc.sys.capabilities ) {
            this.shader.use();
            this.shader.updateUniforms();
            this.shader.setUniformsForBuiltins();
            
            this.shader2.use();
            this.shader2.setUniformLocationWith1f(this.shader2.getUniformLocationForName('u_radius'), Math.abs(this.sprite2.getRotation() / 500));
            this.shader2.updateUniforms();
            this.shader2.setUniformsForBuiltins();

            this.time = Math.sin((Date.now() - this.startTime)/1000)/2;


            this.shader3.use();
            this.shader2.setUniformLocationWith1f(this.shader2.getUniformLocationForName('u_time'), this.time);

            this.shader3.updateUniforms();
            this.shader3.setUniformsForBuiltins();
        }
    },
});

var HelloWorldScene = cc.Scene.extend({
    onEnter:function () {
        this._super();
        var layer = new HelloWorldLayer();
        this.addChild(layer);
    }
});

function testShader(sprite, layer) {
    var vsh = "\n" +
            "attribute vec4 a_position;\n" +
            "attribute vec2 a_texCoord;\n" +
            "attribute vec4 a_color;\n" +
            "varying vec4 v_fragmentColor;\n" +
            "varying vec2 v_texCoord;\n" +
            "void main()\n" +
            "\n{\n" +
            "   gl_Position = CC_PMatrix * a_position;\n" +
            "   v_fragmentColor = a_color;\n" +
            "   v_texCoord = a_texCoord;\n" +
            "}";

   　　　　var fsh = "\n" +
            "varying vec2 v_texCoord;\n" +
            "void main()\n" +
            "\n{\n" +
            "   vec2 coord = v_texCoord;\n" +
            "   coord.x += (sin(coord.y * 10.0 + CC_Time[1] * 10.0) / 30.0);\n" +
            "   gl_FragColor = texture2D(CC_Texture0, coord);\n" +
            "}";


        layer.shader = new cc.GLProgram();
        if(layer.shader.initWithString(vsh, fsh)){
            layer.shader.addAttribute(cc.ATTRIBUTE_NAME_COLOR, cc.VERTEX_ATTRIB_COLOR);
            layer.shader.addAttribute(cc.ATTRIBUTE_NAME_POSITION, cc.VERTEX_ATTRIB_POSITION);
            layer.shader.addAttribute(cc.ATTRIBUTE_NAME_TEX_COORD, cc.VERTEX_ATTRIB_TEX_COORDS);
            layer.shader.link();
            layer.shader.updateUniforms();
            layer.shader.setUniformsForBuiltins();
            layer.shader.use();

            sprite.shaderProgram = layer.shader;
        }

}

function testOutline(layer) {
    
    layer.sprite2 = new cc.Sprite(res.grossini);
    var size = cc.winSize;

    layer.sprite2.attr({
        x: size.width / 2 - 200,
        y: size.height / 2
    });
    layer.sprite2.runAction(cc.sequence(cc.rotateTo(1.0, 10), cc.rotateTo(1.0, -10)).repeatForever());

    layer.shader2 = new cc.GLProgram(res.test_vsh, res.test_fsh);

    layer.shader2.addAttribute(cc.ATTRIBUTE_NAME_POSITION, cc.VERTEX_ATTRIB_POSITION);
    layer.shader2.addAttribute(cc.ATTRIBUTE_NAME_TEX_COORD, cc.VERTEX_ATTRIB_TEX_COORDS);
    layer.shader2.addAttribute(cc.ATTRIBUTE_NAME_COLOR, cc.VERTEX_ATTRIB_COLOR);

    layer.shader2.link();
    layer.shader2.updateUniforms();
    
    layer.shader2.use();
    layer.shader2.setUniformsForBuiltins();

    layer.shader2.setUniformLocationWith1f(layer.shader2.getUniformLocationForName('u_threshold'), 1.75);
    layer.shader2.setUniformLocationWith3f(layer.shader2.getUniformLocationForName('u_outlineColor'), 0 / 255, 255 / 255, 0 / 255);

    layer.sprite2.shaderProgram = layer.shader2;

    layer.addChild(layer.sprite2, 0);
}


function testWater(layer) {
    
    layer.sprite3 = new cc.Sprite(res.water_map);
    var size = cc.winSize;

    layer.sprite3.attr({
        x: size.width / 2 + 300,
        y: size.height / 2
    });
    layer.shader3 = new cc.GLProgram(res.water_vsh, res.water_fsh);

    var texture = cc.textureCache.addImage(res.water_normal);
    texture.setTexParameters(cc.LINEAR, cc.LINEAR, cc.REPEAT, cc.REPEAT);
    layer.texture = texture;

    layer.shader3.addAttribute(cc.ATTRIBUTE_NAME_POSITION, cc.VERTEX_ATTRIB_POSITION);
    layer.shader3.addAttribute(cc.ATTRIBUTE_NAME_TEX_COORD, cc.VERTEX_ATTRIB_TEX_COORDS);
    layer.shader3.addAttribute(cc.ATTRIBUTE_NAME_COLOR, cc.VERTEX_ATTRIB_COLOR);

    layer.shader3.link();
    layer.shader3.updateUniforms();
    
    layer.shader3.use();
    layer.shader3.setUniformsForBuiltins();

    layer.sprite3.shaderProgram = layer.shader3;
    layer.sprite3.getGLProgramState().setUniformTexture(layer.shader3.getUniformLocationForName('u_normalMap'), texture);
    
    layer.addChild(layer.sprite3, 0);
}



cc.GLNode = cc.GLNode || cc.Node.extend({
    ctor:function(){
        this._super();
        this.init();
    },
    init:function(){
        this._renderCmd._needDraw = true;
        this._renderCmd._matrix = new cc.math.Matrix4();
        this._renderCmd._matrix.identity();
        this._renderCmd.rendering =  function(ctx){
            var wt = this._worldTransform;
            this._matrix.mat[0] = wt.a;
            this._matrix.mat[4] = wt.c;
            this._matrix.mat[12] = wt.tx;
            this._matrix.mat[1] = wt.b;
            this._matrix.mat[5] = wt.d;
            this._matrix.mat[13] = wt.ty;

            cc.kmGLMatrixMode(cc.KM_GL_MODELVIEW);
            cc.kmGLPushMatrix();
            cc.kmGLLoadMatrix(this._matrix);

            this._node.draw(ctx);

            cc.kmGLPopMatrix();
        };
    },
    draw:function(ctx){
        this._super(ctx);
    }
});


